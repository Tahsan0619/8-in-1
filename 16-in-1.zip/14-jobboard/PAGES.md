# Job Board & Career Platform — Page Layouts

---

## Homepage Layout

```
┌─────────────────────────────────────────────────────────┐
│  HEADER: Logo | Find Jobs | Companies | Salary | 🌓 👤  │
│  [Post a Job]                                           │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │           HERO (50vh, professional bg)           │    │
│  │                                                  │    │
│  │     Find Your Dream Job                          │    │
│  │     Thousands of opportunities await             │    │
│  │                                                  │    │
│  │  ┌──────────────────────────────────────────┐    │    │
│  │  │ 🔍 Job title  │ 📍 Location │ [Search]   │    │    │
│  │  └──────────────────────────────────────────┘    │    │
│  │  Popular: Frontend Dev • UI Designer • Marketing │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ─── BY THE NUMBERS ──────────────────────              │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                   │
│  │ 5K+  │ │ 800+ │ │ 200+ │ │ 95%  │                   │
│  │ Jobs │ │Compan││ │Hiring│ │Satis.│                   │
│  └──────┘ └──────┘ └──────┘ └──────┘                   │
│                                                         │
│  ─── FEATURED JOBS ─────────────────────── View All     │
│  ┌─────────────────────────────────────────────────┐    │
│  │ 🏢 TechCorp │ Senior React Dev │ Dhaka          │    │
│  │ ৳80-120K/mo │ Full-time │ 2d ago │ [Apply] [♡]  │    │
│  ├─────────────────────────────────────────────────┤    │
│  │ 🏢 FinServ  │ Product Designer │ Remote          │    │
│  │ ৳60-90K/mo  │ Full-time │ 1d ago │ [Apply] [♡]  │    │
│  ├─────────────────────────────────────────────────┤    │
│  │ 🏢 DataInc  │ Data Analyst    │ Chittagong      │    │
│  │ ৳50-70K/mo  │ Full-time │ 3d ago │ [Apply] [♡]  │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ─── TOP COMPANIES ─────────────────────── View All     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │
│  │ 🏢 Logo  │ │ 🏢 Logo  │ │ 🏢 Logo  │ │ 🏢 Logo  │   │
│  │ TechCorp │ │ FinServ  │ │ DataInc  │ │ CloudBD  │   │
│  │ ★4.5     │ │ ★4.3     │ │ ★4.6     │ │ ★4.4     │   │
│  │ 12 jobs  │ │ 8 jobs   │ │ 5 jobs   │ │ 15 jobs  │   │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘   │
│                                                         │
│  ─── BROWSE BY CATEGORY ────────────────────────        │
│  [💻 Tech] [📊 Finance] [🎨 Design] [📈 Marketing]      │
│  [🏗 Engineering] [📋 Admin] [🎓 Education] [🏥 Health]  │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  FOOTER: Quick Links | For Employers | Support | © 2026│
└─────────────────────────────────────────────────────────┘
```

---

## Job Search Layout

```
┌─────────────────────────────────────────────────────────┐
│  HEADER                                                 │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────┐    │
│  │ 🔍 Job title or keyword │ 📍 Location │ [Search]│    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌────────────┬────────────────────────────────────┐    │
│  │  FILTERS   │  Showing 248 Jobs │ Sort: Date [▼] │    │
│  │            │                                    │    │
│  │ Job Type   │  ┌───────────────────────────────┐  │    │
│  │ ☐ Full-time│  │ 🏢 TechCorp                   │  │    │
│  │ ☐ Part-time│  │ Senior Frontend Developer      │  │    │
│  │ ☐ Contract │  │ 📍 Dhaka │ Full-time            │  │    │
│  │ ☐ Remote   │  │ ৳80,000 - ৳120,000/mo         │  │    │
│  │ ☐ Intern   │  │ React, TypeScript, Node        │  │    │
│  │            │  │ Posted 2d ago     [Apply] [♡]  │  │    │
│  │ Experience │  └───────────────────────────────┘  │    │
│  │ ○ Entry    │  ┌───────────────────────────────┐  │    │
│  │ ○ Mid      │  │ 🏢 DesignHub                  │  │    │
│  │ ○ Senior   │  │ UI/UX Designer                │  │    │
│  │ ○ Lead     │  │ 📍 Remote │ Full-time          │  │    │
│  │            │  │ ৳60,000 - ৳90,000/mo          │  │    │
│  │ Salary     │  │ Figma, Adobe XD, CSS          │  │    │
│  │ [Min]-[Max]│  │ Posted 1d ago     [Apply] [♡] │  │    │
│  │            │  └───────────────────────────────┘  │    │
│  │ Industry   │                                    │    │
│  │ [Select ▼] │  ◀ 1 2 3 ... 25 ▶                 │    │
│  │            │                                    │    │
│  │ [Clear All]│                                    │    │
│  └────────────┴────────────────────────────────────┘    │
├─────────────────────────────────────────────────────────┤
│  FOOTER                                                 │
└─────────────────────────────────────────────────────────┘
```

---

## Job Detail Layout

```
┌─────────────────────────────────────────────────────────┐
│  HEADER                                                 │
├─────────────────────────────────────────────────────────┤
│  ← Back to Jobs                                        │
│                                                         │
│  ┌──────────────────────────────┬──────────────────┐    │
│  │  🏢 TechCorp                │  APPLY SIDEBAR    │    │
│  │  Senior Frontend Developer  │                   │    │
│  │  📍 Dhaka │ Full-time       │  ৳80K-120K/mo     │    │
│  │  Posted 2 days ago          │                   │    │
│  │                              │  [Apply Now]      │    │
│  │  ── Job Description ──      │  [♡ Save Job]     │    │
│  │  We're looking for an       │                   │    │
│  │  experienced frontend dev   │  ── JOB FACTS ── │    │
│  │  to join our team...        │  Type: Full-time  │    │
│  │                              │  Level: Senior    │    │
│  │  ── Requirements ──         │  Exp: 5+ years    │    │
│  │  • 5+ years React          │  Vacancy: 2       │    │
│  │  • TypeScript proficiency   │  Deadline: Feb 15 │    │
│  │  • Node.js experience      │                   │    │
│  │  • RESTful APIs             │  ── SKILLS ──     │    │
│  │                              │  [React] [TS]     │    │
│  │  ── Benefits ──             │  [Node] [CSS]     │    │
│  │  • Health insurance         │                   │    │
│  │  • Remote-friendly          │  ── COMPANY ──    │    │
│  │  • Learning budget          │  🏢 TechCorp      │    │
│  │  • Festival bonus           │  ★4.5 (42 reviews)│   │
│  │                              │  [View Company]   │    │
│  └──────────────────────────────┴──────────────────┘    │
│                                                         │
│  ── SIMILAR JOBS ──                                     │
│  [JobCard] [JobCard] [JobCard]                          │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  FOOTER                                                 │
└─────────────────────────────────────────────────────────┘
```

---

## Company Profile Layout

```
┌─────────────────────────────────────────────────────────┐
│  HEADER                                                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │ 🏢 TechCorp Bangladesh                          │    │
│  │ Technology • Dhaka • 500+ employees             │    │
│  │ ★★★★½ (42 reviews)                              │    │
│  │ est. 2015 │ www.techcorp.com.bd                 │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌────────────────────────────────────────────────┐     │
│  │ [About] [Open Jobs (12)] [Reviews] [Benefits]  │     │
│  │────────────────────────────────────────────────│     │
│  │  ABOUT:                                        │     │
│  │  TechCorp is a leading software company...     │     │
│  │                                                │     │
│  │  OPEN POSITIONS:                               │     │
│  │  │ Sr. Frontend Dev │ Dhaka │ ৳80-120K │ Apply ││    │
│  │  │ Product Designer │ Remote │ ৳60-90K │ Apply ││    │
│  │  │ Data Engineer    │ Dhaka │ ৳70-100K │ Apply ││    │
│  │                                                │     │
│  │  REVIEWS:                                      │     │
│  │  [Review Card] [Review Card]                   │     │
│  │                                                │     │
│  │  BENEFITS & CULTURE:                           │     │
│  │  [Health] [Remote] [Learning] [Festival Bonus] │     │
│  └────────────────────────────────────────────────┘     │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  FOOTER                                                 │
└─────────────────────────────────────────────────────────┘
```

---

## Candidate Dashboard Layout

```
┌─────────────────────────────────────────────────────────┐
│  HEADER                                                 │
├──────────┬──────────────────────────────────────────────┤
│          │  Welcome, Tahsan                              │
│ SIDEBAR  │  Profile Completion: ████████░░ 80%           │
│          │                                              │
│ 📊 Dash  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐        │
│ 📄 Apps  │  │Applied│ │ Inter│ │ Saved│ │ Views│        │
│ ♡ Saved  │  │  12   │ │view 3│ │  8   │ │  45  │        │
│ 📝 Resume│  └──────┘ └──────┘ └──────┘ └──────┘        │
│ 👤 Profile│                                             │
│ ⚙ Settings│ ── APPLICATION PIPELINE ──                   │
│          │  ┌──────┬──────┬──────┬──────┬──────┐        │
│          │  │Appied│Screen│Interv│ Offer│Result│        │
│          │  │  12  │  5   │  3   │  1   │  2   │        │
│          │  └──────┴──────┴──────┴──────┴──────┘        │
│          │                                              │
│          │  ── RECENT APPLICATIONS ──                    │
│          │  │ TechCorp │ Sr. Frontend │ Applied │ 2d   │
│          │  │ FinServ  │ Product Des. │ Interview│ 5d  │
│          │  │ DataInc  │ Data Analyst │ Rejected │ 7d  │
│          │                                              │
│          │  ── SAVED JOBS ──                             │
│          │  │ CloudBD │ DevOps Eng. │ ৳90K │ [Apply]   │
│          │  │ AppLab  │ Mobile Dev  │ ৳70K │ [Apply]   │
│          │                                              │
├──────────┴──────────────────────────────────────────────┤
│  FOOTER                                                 │
└─────────────────────────────────────────────────────────┘
```

---

## Employer Dashboard Layout

```
┌─────────────────────────────────────────────────────────┐
│  SIDEBAR │  Employer Dashboard — TechCorp               │
├──────────┤──────────────────────────────────────────────│
│          │  ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│ 📊 Dash  │  │ Active   │ │ Total    │ │ This     │     │
│ 📋 Jobs  │  │ Jobs: 12 │ │ Apps: 85 │ │ Month: 32│     │
│ 👥 Applic│  └──────────┘ └──────────┘ └──────────┘     │
│ 📈 Analyt│                                              │
│ 🏢 Company│ ── APPLICANT PIPELINE (Kanban) ──           │
│ ⚙ Settings│ ┌──────┬──────┬──────┬──────┬──────┐       │
│          │  │ New  │Screen│Interv│Offer │Hired │       │
│          │  │──────│──────│──────│──────│──────│       │
│          │  │[card]│[card]│[card]│[card]│      │       │
│          │  │[card]│[card]│      │      │      │       │
│          │  │[card]│      │      │      │      │       │
│          │  └──────┴──────┴──────┴──────┴──────┘       │
│          │  (drag cards between columns)                │
│          │                                              │
│          │  ── APPLICATIONS TREND (Chart.js) ──          │
│          │  [Line chart: applications over 30 days]      │
│          │                                              │
└──────────┴──────────────────────────────────────────────┘
```

---

## Salary Insights Layout

```
┌─────────────────────────────────────────────────────────┐
│  HEADER                                                 │
├─────────────────────────────────────────────────────────┤
│  Salary Insights                                        │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │ Role: [Frontend Developer ▼]  Location: [All ▼] │    │
│  │ Experience: [All ▼]                              │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌────────────────────┬────────────────────────────┐    │
│  │  SALARY RANGE      │  BY EXPERIENCE (Bar Chart) │    │
│  │                    │                            │    │
│  │  Avg: ৳85,000/mo   │  Entry:  ████ ৳40K        │    │
│  │  Min: ৳40,000/mo   │  Mid:    ██████ ৳70K      │    │
│  │  Max: ৳150,000/mo  │  Senior: █████████ ৳110K  │    │
│  │                    │  Lead:   ██████████ ৳140K  │    │
│  │  [Gauge visual]    │                            │    │
│  └────────────────────┴────────────────────────────┘    │
│                                                         │
│  ── SALARY TREND (Line Chart, last 12 months) ──        │
│  [Chart showing average salary trending up]              │
│                                                         │
│  ── TOP PAYING COMPANIES ──                             │
│  │ TechCorp │ ৳120K avg │ CloudBD │ ৳110K avg │       │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  FOOTER                                                 │
└─────────────────────────────────────────────────────────┘
```
